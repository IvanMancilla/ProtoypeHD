<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\participant;
use App\course;
use App\Providers\RouteServiceProvider;
use Illuminate\Support\Facades\DB;

class courseController extends Controller
{
    public function showCourses(){

    	$courses = course::all();
    	//dd($cursos);

    	return view('courses', compact('courses'));


    }
}
