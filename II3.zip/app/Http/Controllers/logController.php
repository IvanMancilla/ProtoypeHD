<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\participant;
use App\Providers\RouteServiceProvider;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Mail\Mailer;
use Illuminate\Mail\Mailable;
use App\Mail\confirm;
//use Mail;

class logController extends Controller
{
    public function showLog()
    {

        return view('log');

    }

    public function enviarMail()
    {
    	$receivers = participant::pluck('participantEmail');
    	//dd($receivers);
        Mail::to($receivers)->send(new confirm);
    }

    public function createUser()
    {
        //Falta vrificación de correo y contraseña

    	$data = request()->all();
        $e= "El usuario existe";
        $verifyMail = DB::table('participants')->where('participantEmail',$data['email'])->first();
        if ($verifyMail==null) {
            //dd($verrifyMail);
            
            participant::create([

                'participantFirstName' => $data['name'],
                'participantLastName' => $data['lastName'],
                'participantEmail' => $data['email'],
                'participantPassword' => sha1($data['password']),
                'participantBirthday' => $data['birthday'],
                
                    'participantPhone' => $data['phone_num'],
                'participantHQR'=> '/',
                'participantCountry' => $data['country'],
                'participantRegion' => $data['region'],
                
                    'participantCP' => $data['CP'],    
                
                'createdBy' => '100000000',
                'modifyDate' => date_create(),
                'modifyBy' => '100000000'
                

                
/*
            'type'=>'S',
            'status'=>'A',
            'name'=>$data['name'],
            'lname_p'=>$data['lname_p'],
            'lname_m'=>$data['lname_m'],
            'birthday'=>$data['birthday'],
            'img_path'=>'/',
            'hqr_path'=>'/',
            'email'=>$data['email'],
            'password'=>sha1($data['password']),
            'phone_num'=>$data['phone_num'],
            'country'=>$data['country'],
            'region'=>$data['region'],
            'city'=>$data['city'],
            'created_date'=>date_create(),
            'created_by'=>'1000000',
            'modify_date'=>date_create(),
            'modify_by'=>'1000000',         */
            
        ]);
           
        }else{
            
            return redirect('/registro')->withInput()->with('err','El email ya se encuentra registrado');
            //return view('registro', compact('e'))->withInput();
        }
 		
        return redirect('/');
        //signup_user("A", "Carlos Alberto", "Campana", "Villanueva", "1996-07-12", "ksy50p.ccv@gmail.com", sha1("123456"), "527227073234", "México", "Estado de México", "Toluca", "1000000");


        //self::regresar();
        //action('logController@regresar');
        //return logController::regresar();

        //return logController::signup_user("A", "Carlos Alberto", "Campana", "Villanueva", "1996-07-12", "ksy50p.ccv@gmail.com", sha1("123456"), "527227073234", "México", "Estado de México", "Toluca", "1000000");

        

    }
}
