@extends('template')
@section('title')
<title>Cursos || J I E</title>
@endSection
@section('content')
<div class="row " style="background-color: #aaa">
  <div class="col">
    <br><br><br>
  </div>
</div>
<div class="row bgWhite">
	<div class="col">
    <br>
		@foreach($courses as $course)
		
			<div class="card mb-3" style="max-width: 80%;">
  <div class="row no-gutters">
    <div class="col-md-4" style="background-image: url(/images/city2.jpg); background-size: cover;">
      
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h5 class="card-title">{{$course->courseName}}</h5>
        <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
        <a href="#" class="btn bgGold" style="width: 300px;">Más detalles</a>
        <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
      </div>
    </div>
  </div>
</div>
		<br>
		@endForeach
	</div>
</div>
@endSection