@extends('template')
@section('title')
<title>Registro || J I E</title>
@endSection
@section('content')
<div class="row parallaxRegister">
	
	<div class="col-sm-1 col-md-2 col-lg-3"><br></div>

	<div class="col bgWhite " style="max-width: 600px;" ><!--Start col center-->
	<form action="{{route('create')}}" method="POST" style="font-size: 12px; max-width: 600px;margin: 5%; " class="form-container bgWhite">
    {{ csrf_field() }}
    <div class="row">
        <div class="col">
            <h1 class="gold" style="color: #FECE78;">Registro</h1>
    <label for="name">*Nombre(s):</label>
    <input type="text" onkeypress="return checkLetra(event)" name="name" class="form-control" value="{{old('name')}}" placeholder="Nombre" required>
        </div>

    </div>
    <br>
    <div class="row">
        <div class="col-6">
            <label for="lastName">*Apellidos:</label>
    <input type="text" class="form-control" value="{{old('lastName')}}" onkeypress="return checkLetra(event)" name="lastName" placeholder="Apellido Paterno" required>

        </div>
        <div class="col-6">
            <label for="birthday">*Fecha de nacimiento:</label>
            <input type="date" value="{{old('birthday')}}" name="birthday" max="2003-01-01" class="form-control"  id="datefield" required>
        </div>
        
    </div>
    <hr>
   
    <div class="row">

        <div class="col ">
            <label for="email" >*Correo</label>
            <input type="email"value="{{old('email')}}" name="email" id="usuario" class="form-control @if(session('err'))
            is-invalid
            @endIf
            " required>
            @if(session('err'))
            <div class="invalid-feedback">
          El correo ya se encuentra registrado
        </div>
        @endIf
        </div>


    </div>
    <br>
    <div class="row">
        

        <div class="col ">
            <label for="password" >*Contraseña</label>
            <input type="password"  minlength="6" name="password" class="form-control" required>
        </div>


    </div>
    
    <div class="row">
        

        <div class="col ">
            <label for="password" >*Repetir contraseña</label>
            <input type="password"  minlength="6" name="password" class="form-control" required>
        </div>


    </div>
    <hr>
    <div class="row">
        <div class="col">
        <label for="phone_num">Teléfono</label>
        <input type="tel" value="{{old('phone_num')}}" name="phone_num" class="form-control">
        </div>
        <div class="col">
          <label for="country">País</label>
        <input type="tel" value="{{old('country')}}" name="country" class="form-control">
        </div>
        
        
    </div>  
    <br>
    <div class="row">
        
        <div class="col">
            <label for="region">Estado</label>
            <input type="text" value="{{old('region')}}" onkeypress="return checkLetra(event)" name="region" class="form-control">
        </div>
        <div class="col">
            <label for="CP">Código postal</label>
            <input type="text" value="{{old('CP')}}" onkeypress="return checkLetra(event)" name="CP" class="form-control">
        </div>
    </div>  
    
    <hr>
    <button type="submit" role="button" class="btn">Registrarse</button>
  </form></div><!--End col center-->
  <div class="col-sm-1 col-md-2 col-lg-3" >
  	
  </div>
	
</div><!--END ROW parallax-->




@endSection