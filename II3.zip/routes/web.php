<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});
Route::POST('/login', 'Auth\LoginController@Login')->name('Login');

//Auth::routes();
Route::GET('/cursos', 'courseController@showCourses');

Route::GET('/registro', function(){
	return view('register');
});
Route::POST('/create', 'logController@createUser')->name('create');

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/mail','logController@enviarMail');
