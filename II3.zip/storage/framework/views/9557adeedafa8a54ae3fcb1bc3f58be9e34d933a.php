
<?php $__env->startSection('title'); ?>
<title>Cursos || J I E</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row " style="background-color: #aaa">
  <div class="col">
    <br><br><br>
  </div>
</div>
<div class="row bgWhite">
	<div class="col">
    <br>
		<?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		
			<div class="card mb-3" style="max-width: 80%;">
  <div class="row no-gutters">
    <div class="col-md-4" style="background-image: url(/images/city2.jpg); background-size: cover;">
      
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h5 class="card-title"><?php echo e($course->courseName); ?></h5>
        <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
        <a href="#" class="btn bgGold" style="width: 300px;">Más detalles</a>
        <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
      </div>
    </div>
  </div>
</div>
		<br>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\II\resources\views/courses.blade.php ENDPATH**/ ?>